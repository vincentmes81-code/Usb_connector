package com.usbinspector

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.File
import java.io.FileReader

class MainActivity : AppCompatActivity() {

    private lateinit var usbManager: UsbManager
    private lateinit var batteryManager: BatteryManager
    private lateinit var statusIcon: TextView
    private lateinit var statusTitle: TextView
    private lateinit var statusSubtitle: TextView
    private lateinit var infoContainer: LinearLayout
    private lateinit var scanButton: Button

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    }
                    device?.let { analyzeConnection(it) } ?: scanCurrentState()
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> showDisconnected()
                Intent.ACTION_POWER_CONNECTED -> scanCurrentState()
                Intent.ACTION_POWER_DISCONNECTED -> showDisconnected()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        statusIcon = findViewById(R.id.statusIcon)
        statusTitle = findViewById(R.id.statusTitle)
        statusSubtitle = findViewById(R.id.statusSubtitle)
        infoContainer = findViewById(R.id.infoContainer)
        scanButton = findViewById(R.id.scanButton)

        scanButton.setOnClickListener { scanCurrentState() }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(usbReceiver, filter)

        scanCurrentState()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
    }

    private fun scanCurrentState() {
        val devices = usbManager.deviceList
        if (devices.isNotEmpty()) {
            analyzeConnection(devices.values.first())
        } else {
            analyzeCharging()
        }
    }

    private fun analyzeCharging() {
        val isBatteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = isBatteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1

        if (plugged == BatteryManager.BATTERY_PLUGGED_USB) {
            showChargingInfo()
        } else if (plugged == BatteryManager.BATTERY_PLUGGED_AC) {
            showChargingInfo()
        } else {
            showDisconnected()
        }
    }

    private fun analyzeConnection(device: UsbDevice) {
        setConnectedState()
        infoContainer.removeAllViews()

        // USB Device Identity
        addSection("🔌 USB Device Identity")
        addInfoRow("Device Name", device.deviceName)
        addInfoRow("Manufacturer", device.manufacturerName ?: readSysfs("manufacturer") ?: "Unknown")
        addInfoRow("Product", device.productName ?: readSysfs("product") ?: "Unknown")
        addInfoRow("Serial", device.serialNumber ?: readSysfs("serial") ?: "Not accessible")
        addInfoRow("Vendor ID", "0x%04X".format(device.vendorId))
        addInfoRow("Product ID", "0x%04X".format(device.productId))

        // USB Version & Speed
        addSection("⚡ USB Standard & Speed")
        val usbVersion = getUsbVersion(device)
        addInfoRow("USB Version", usbVersion.version)
        addInfoRow("Max Speed", usbVersion.speed)
        addInfoRow("Connector", "USB-C")

        // Interface & Class Info
        addSection("🔧 Interfaces")
        addInfoRow("Interface Count", device.interfaceCount.toString())
        val classes = (0 until device.interfaceCount).map { i ->
            val iface = device.getInterface(i)
            getUsbClassName(iface.interfaceClass)
        }.distinct()
        addInfoRow("Functions", classes.joinToString(", "))

        // Power / Charging
        addSection("🔋 Power & Charging")
        val chargingInfo = getChargingInfo()
        addInfoRow("Charging Status", chargingInfo.status)
        addInfoRow("Current (μA)", chargingInfo.currentMicro)
        addInfoRow("Voltage (mV)", chargingInfo.voltageMv)
        addInfoRow("Power", chargingInfo.watts)
        addInfoRow("Charge Type", chargingInfo.chargeType)

        // Sysfs deep info
        addSection("📊 Kernel / Sysfs Data")
        val sysfsSpeed = readSysfs("speed")
        val sysfsVersion = readSysfs("version")
        val sysfsMaxCurrent = readSysfs("bMaxPower")
        addInfoRow("Reported Speed", sysfsSpeed ?: "N/A")
        addInfoRow("USB bcdUSB", sysfsVersion ?: "N/A")
        addInfoRow("Max Power (bMaxPower)", sysfsMaxCurrent?.let { "${it.trim().toIntOrNull()?.times(2) ?: it} mA" } ?: "N/A")

        // Alt Modes (USB4 / Thunderbolt / DP)
        addSection("🖥️ Alternate Modes")
        val altModes = detectAltModes()
        addInfoRow("DisplayPort Alt", if (altModes.displayPort) "✅ Supported" else "❌ Not detected")
        addInfoRow("USB4 / TB4", if (altModes.usb4) "✅ Supported" else "❌ Not detected")
        addInfoRow("MHL", if (altModes.mhl) "✅ Supported" else "❌ Not detected")

        // Cable inference
        addSection("🧠 Cable Analysis")
        val inference = inferCableQuality(device, chargingInfo, usbVersion)
        addInfoRow("Estimated Cable Grade", inference.grade)
        addInfoRow("E-Marker Chip", inference.eMarker)
        addInfoRow("Notes", inference.notes)
    }

    private fun showChargingInfo() {
        setConnectedState()
        infoContainer.removeAllViews()

        addSection("🔋 Charging Info (no USB data device)")
        val chargingInfo = getChargingInfo()
        addInfoRow("Status", chargingInfo.status)
        addInfoRow("Current (μA)", chargingInfo.currentMicro)
        addInfoRow("Voltage (mV)", chargingInfo.voltageMv)
        addInfoRow("Power", chargingInfo.watts)
        addInfoRow("Charge Type", chargingInfo.chargeType)

        addSection("ℹ️ Why limited info?")
        addInfoRow("Reason", "Charger/cable only — no USB data device enumerated. Plug into a computer or USB hub for full cable details.")
    }

    private fun showDisconnected() {
        statusIcon.text = "○"
        statusIcon.setTextColor(ContextCompat.getColor(this, R.color.gray))
        statusTitle.text = "No Cable Detected"
        statusSubtitle.text = "Plug in a USB-C cable to inspect it"
        infoContainer.removeAllViews()
    }

    private fun setConnectedState() {
        statusIcon.text = "●"
        statusIcon.setTextColor(ContextCompat.getColor(this, R.color.green))
        statusTitle.text = "Cable Connected"
        statusSubtitle.text = "Analyzing capabilities..."
    }

    private fun addSection(title: String) {
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 13f
        tv.setTypeface(null, android.graphics.Typeface.BOLD)
        tv.setTextColor(ContextCompat.getColor(this, R.color.accent))
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, dpToPx(16), 0, dpToPx(4))
        tv.layoutParams = params
        infoContainer.addView(tv)

        val divider = View(this)
        divider.setBackgroundColor(ContextCompat.getColor(this, R.color.accent))
        val dp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1))
        dp.setMargins(0, 0, 0, dpToPx(8))
        divider.layoutParams = dp
        infoContainer.addView(divider)
    }

    private fun addInfoRow(label: String, value: String) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 0, 0, dpToPx(6))
        row.layoutParams = params

        val labelView = TextView(this)
        labelView.text = label
        labelView.textSize = 12f
        labelView.setTextColor(ContextCompat.getColor(this, R.color.label))
        labelView.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

        val valueView = TextView(this)
        valueView.text = value
        valueView.textSize = 12f
        valueView.setTextColor(ContextCompat.getColor(this, R.color.value))
        valueView.gravity = android.view.Gravity.END
        valueView.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

        row.addView(labelView)
        row.addView(valueView)
        infoContainer.addView(row)
    }

    // --- Data Helpers ---

    data class UsbVersionInfo(val version: String, val speed: String)
    data class ChargingInfo(val status: String, val currentMicro: String, val voltageMv: String, val watts: String, val chargeType: String)
    data class AltModes(val displayPort: Boolean, val usb4: Boolean, val mhl: Boolean)
    data class CableInference(val grade: String, val eMarker: String, val notes: String)

    private fun getUsbVersion(device: UsbDevice): UsbVersionInfo {
        // Try sysfs speed first
        val speed = readSysfs("speed")?.trim()?.toIntOrNull()
        return when {
            speed != null && speed >= 10000 -> UsbVersionInfo("USB 3.1 Gen 2 / USB4", "10+ Gbps")
            speed != null && speed >= 5000 -> UsbVersionInfo("USB 3.1 Gen 1", "5 Gbps")
            speed != null && speed >= 480 -> UsbVersionInfo("USB 2.0 (Hi-Speed)", "480 Mbps")
            speed != null && speed >= 12 -> UsbVersionInfo("USB 1.1 (Full Speed)", "12 Mbps")
            device.deviceClass == 9 -> UsbVersionInfo("USB Hub", "Varies")
            else -> {
                // Infer from device version
                val ver = readSysfs("version")?.trim() ?: "2.00"
                when {
                    ver.startsWith("3.2") || ver.startsWith("4") -> UsbVersionInfo("USB 3.2 / USB4", "20+ Gbps")
                    ver.startsWith("3.1") -> UsbVersionInfo("USB 3.1", "10 Gbps")
                    ver.startsWith("3.0") -> UsbVersionInfo("USB 3.0", "5 Gbps")
                    else -> UsbVersionInfo("USB 2.0", "480 Mbps")
                }
            }
        }
    }

    private fun getChargingInfo(): ChargingInfo {
        val currentNow = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val voltage = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_VOLTAGE)
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1

        val statusStr = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
            else -> "Unknown"
        }

        val absCurrentMicro = Math.abs(currentNow)
        val currentMa = absCurrentMicro / 1000f
        val voltageMv = voltage
        val watts = if (voltageMv > 0 && absCurrentMicro > 0) {
            "%.2f W".format((voltageMv / 1000f) * (absCurrentMicro / 1_000_000f))
        } else "N/A"

        val chargeType = when {
            plugged == BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter (fast)"
            plugged == BatteryManager.BATTERY_PLUGGED_USB -> "USB (standard)"
            plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            currentMa > 2000 -> "Fast Charge / PD"
            currentMa > 500 -> "Standard USB Charge"
            else -> "Trickle / None"
        }

        return ChargingInfo(
            statusStr,
            if (absCurrentMicro > 0) "$absCurrentMicro μA (${currentMa.toInt()} mA)" else "N/A",
            if (voltageMv > 0) "$voltageMv mV" else "N/A",
            watts,
            chargeType
        )
    }

    private fun detectAltModes(): AltModes {
        // Check sysfs for alt mode info
        val typecPath = "/sys/class/typec"
        var dp = false
        var usb4 = false
        var mhl = false
        try {
            val dir = File(typecPath)
            if (dir.exists()) {
                dir.listFiles()?.forEach { portDir ->
                    portDir.listFiles()?.forEach { f ->
                        val content = f.readText().lowercase()
                        if (content.contains("displayport") || content.contains("dp")) dp = true
                        if (content.contains("usb4") || content.contains("thunderbolt")) usb4 = true
                        if (content.contains("mhl")) mhl = true
                    }
                }
            }
        } catch (_: Exception) {}
        return AltModes(dp, usb4, mhl)
    }

    private fun inferCableQuality(device: UsbDevice, charging: ChargingInfo, ver: UsbVersionInfo): CableInference {
        val currentMa = charging.currentMicro.substringBefore(" μA").toIntOrNull()?.div(1000) ?: 0
        val isHighSpeed = ver.version.contains("3") || ver.version.contains("4")
        val isHighPower = currentMa > 2000

        val grade = when {
            isHighSpeed && isHighPower -> "Premium (USB 3.x + High Power)"
            isHighSpeed -> "Data Cable (USB 3.x, power unknown)"
            isHighPower -> "Charging Cable (High Power, USB 2.0 data)"
            currentMa in 500..2000 -> "Standard Cable (USB 2.0, normal charging)"
            else -> "Basic / Passive Cable"
        }

        val eMarker = when {
            isHighSpeed && isHighPower -> "Likely E-Marked (5A rated)"
            isHighPower -> "Possibly E-Marked"
            else -> "Not required / Not detected"
        }

        val notes = when {
            isHighSpeed && isHighPower -> "Good cable — supports full USB-C spec with power and data."
            isHighSpeed -> "Good for data transfer. Power rating unclear from software."
            isHighPower -> "Good charger cable. Data limited to USB 2.0 speeds."
            else -> "Basic cable. Fine for charging at low rates or USB 2.0 data."
        }

        return CableInference(grade, eMarker, notes)
    }

    private fun getUsbClassName(classCode: Int): String = when (classCode) {
        0 -> "Per-Interface"
        1 -> "Audio"
        2 -> "CDC/Comm"
        3 -> "HID"
        5 -> "Physical"
        6 -> "Image"
        7 -> "Printer"
        8 -> "Mass Storage"
        9 -> "Hub"
        10 -> "CDC-Data"
        11 -> "Smart Card"
        13 -> "Content Security"
        14 -> "Video"
        15 -> "Personal Healthcare"
        16 -> "AV"
        17 -> "Billboard"
        220 -> "Diagnostic"
        224 -> "Wireless"
        239 -> "Miscellaneous"
        254 -> "App Specific"
        255 -> "Vendor Specific"
        else -> "Class 0x%02X".format(classCode)
    }

    private fun readSysfs(field: String): String? {
        val devices = usbManager.deviceList
        val deviceName = devices.keys.firstOrNull() ?: return null
        val busNum = deviceName.substringAfter("bus").substringBefore("/").toIntOrNull()
        val devNum = deviceName.substringAfterLast("/").toIntOrNull()
        val paths = listOf(
            "/sys/bus/usb/devices/usb$busNum/$busNum-0/$field",
            "/sys/bus/usb/devices/$busNum-$devNum/$field",
            "/sys/bus/usb/devices/usb1/1-0/$field",
        )
        for (path in paths) {
            try {
                val f = File(path)
                if (f.exists()) return BufferedReader(FileReader(f)).readLine()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
}
